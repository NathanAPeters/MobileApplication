package com.example.mobilea2;

import java.util.Random;

public class Question {
    /**
     * =============================== Question specific info ==================================
     */
    public String questionAsk;//the text of the question being asked
    public String option1;//the text of the 1st button the user can select
    public String option2;//2nd button
    public String option3;
    public String option4;
    public String correctAnswer;//the answer the user is trying to guess

    /**
     * =============================== Other useful fields ======================================
     */
    public boolean questionIsAnswered;//this is to lock the question from being answered again
    public boolean questionIsCorrect;//useful for telling the color to be green or red when recalling the code
    public int correctIndex;//useful for, once again you guessed it (colors babyyyy)

    // TODO: Implement and image field here, include


    /**
     * =========================== Color based fields ======================================
     */
    public int correctColor = R.color.correctColor;
    public int wrongColor = R.color.wrongColor;
    public int unanswerdColor = R.color.darkblue;
    public int lockedColor = R.color.grey;
    public int userChoiceColor = R.color.darkblue;
    public int userChoiceIndex = -1;

    /**
     * =========================== Constructor for Question Specific Info ======================================
     */
    public Question(String ask, String op1, String op2, String op3, String op4, String correct){
        this.questionAsk = ask;
        this.option1 = op1;
        this.option2 = op2;
        this.option3 = op3;
        this.option4 = op4;
        this.correctAnswer = correct;
    }

    /**
     * =========================== Methods ======================================
     */
    public  void RandomizeQuestion(){//it mixes up the text of the buttons so that they are randomized. because it's based on the text value, it's fine.
        String[] options = {option1, option2, option3, option4};

        // Shuffle the array using Fisher-Yates algorithm. I got this algorithm from ChatGPT and do not own it.
        for (int i = options.length - 1; i > 0; i--) {//start at the end of the options/button text and switch them around a lil bit
            int j = GetRandomNumber(0, i);//random index value to swap to
            Swap(options, i, j);
        }

        //put the result of the randomizing back in
        option1 = options[0];
        option2 = options[1];
        option3 = options[2];
        option4 = options[3];
    }
    private int GetRandomNumber(int min, int max) {//returns a random int
        Random random = new Random();
        return random.nextInt((max - min) + 1) + min;//this is from chat GPT as well (I forgot the syntax of this line, so I just quick scooped it
    }
    private static <T> void Swap(T[] array, int i, int j) {//swaps the value at two array indexes generically
        T temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }


}
