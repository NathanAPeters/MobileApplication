package com.example.mobilea2;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    Question[] questions = new Question[4];//this is all the question data go to the Question class for more info
    int questionIndex = 0;//the question that the user is on
    int scoreVal = 0;
    Button[] btnOptions = new Button[4];
    TextView  score;
    Toolbar question;
    /**
     * =========================== methods used for loading ======================================
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LoadQuestion();
    }
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState){
       super.onSaveInstanceState(outState);

       outState.putInt("SCORE",scoreVal);
       outState.putInt("QUESTION",questionIndex);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        scoreVal = savedInstanceState.getInt("SCORE");
        questionIndex = savedInstanceState.getInt("QUESTION");
        LoadQuestion();
    }

    public void LoadQuestion(){
        getIds();
        setQuestions();
        setQuestionText();
    }
    public void getIds(){//get the buttons from the activity for dynamic changing
        btnOptions[0] = findViewById(R.id.btnOption0);
        btnOptions[1] = findViewById(R.id.btnOption1);
        btnOptions[2] = findViewById(R.id.btnOption2);
        btnOptions[3] = findViewById(R.id.btnOption3);
        question = findViewById(R.id.TextQuestion);
        score = findViewById(R.id.scoreText);
    }
    public void setQuestions(){//create the questions and randomize their positions
        questions[0] = new Question("Who are you","darth Vader", "Nathan", "bob", "Ungus Amogus", "Nathan");
        questions[1] = new Question("what do you do","w", "l", "bin", "pizza", "w");
        questions[2] = new Question("Where are you","beans", "bons", "cones", "bones", "cones");
        questions[3] = new Question("what the dog doing","nerd", "silly", "smart", "fun", "silly");
        for (Question question:questions) {//
            question.RandomizeQuestion();
        }
    }
    public void setQuestionText(){//display the info of the question as well as score on the page
        question.setTitle(questions[questionIndex].questionAsk);
        btnOptions[0].setText(questions[questionIndex].option1);
        btnOptions[1].setText(questions[questionIndex].option2);
        btnOptions[2].setText(questions[questionIndex].option3);
        btnOptions[3].setText(questions[questionIndex].option4);
        score.setText(String.valueOf(scoreVal));
    }
    /**
     * =========================== color methods ======================================
     */
    public void setButtonColors(){
        for (int i = 0; i < btnOptions.length; i++) {
            if(questions[questionIndex].userChoiceIndex == i){//the button that the user chose
                if(questions[questionIndex].questionIsCorrect)//if they chose correctly
                    btnOptions[i].setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, questions[questionIndex].correctColor)));
                else//if they chose incorrectly
                    btnOptions[i].setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, questions[questionIndex].wrongColor)));
            }
            else if(questions[questionIndex].questionIsAnswered){//if the question was answered but it's a button the user didn't select
                if(questions[questionIndex].correctIndex==i && !questions[questionIndex].questionIsCorrect)//if the question was answered wrong, but it's where the correct button would be
                    btnOptions[i].setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, questions[questionIndex].correctColor)));
                else
                    btnOptions[i].setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, questions[questionIndex].lockedColor)));
            }
            else{//if the user didn't chose an answer yet on this question
                btnOptions[i].setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, questions[questionIndex].unanswerdColor)));
            }

        }
    }
    /**
     * =========================== useful methods ======================================
     */
    public int checkBtnClicked(Button button){//this is used in pickAnswer and checks which button the user clicks on
        for (int i = 0; i < btnOptions.length; i++) {
            if(btnOptions[i] == button){//one of the options is the button that you clicked
                return i;//return the index of the option being clicked (if you click the third button save 2 as a choice the user clicked)
            }
        }

        Log.w(TAG, "Forgot to add button into btnOptions");
        return -1;//if the button you clicked isn't contained in btnOptions (should never trigger but needed another return)
    }
    public Button findCorrectButton(){//this is used in pickAnswer
        int i = 0;
        for (Button btn:btnOptions) {
            if(btn.getText() == questions[questionIndex].correctAnswer){//if the button in the array of buttons is the correct answer
                questions[questionIndex].correctIndex = i;//save the index with the correct answer
                return btn;
            }
            i++;
        }
        questions[questionIndex].correctIndex = -1;
        return null;
    }

    /**
     * =========================== onclick methods ======================================
     */
    public void pickAnswer(View view){
        if(!questions[questionIndex].questionIsAnswered){
            Button button = (Button) view;
            if(button.getText().equals(questions[questionIndex].correctAnswer)){//if answered correct
                questions[questionIndex].questionIsCorrect = true;//this bool keeps track of the specific question
                scoreVal++;//if correct add score
                Toast.makeText(this,"Correct!",Toast.LENGTH_SHORT).show();//display a toast on screen congratulating user

                setQuestionText();
                button.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, questions[questionIndex].correctColor)));
                questions[questionIndex].userChoiceColor = R.color.correctColor;
            }
            else{//if answered incorrect
                Button correctButton = findCorrectButton();
                if(correctButton!=null){//is there an actual correct answer (this is used to set the button color for the incorrect and correct answer)
                    Toast.makeText(this,"Wrong!",Toast.LENGTH_SHORT).show();
                    button.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, questions[questionIndex].wrongColor)));
                    correctButton.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, questions[questionIndex].correctColor)));
                }
                else{//if there is no correct answer
                    Toast.makeText(this,"A correct answer not found, please contact ",Toast.LENGTH_SHORT).show();
                }
                questions[questionIndex].userChoiceColor = R.color.wrongColor;
            }
            questions[questionIndex].questionIsAnswered=true;//this locks the question so you can't answer differently
            questions[questionIndex].userChoiceIndex = checkBtnClicked(button);//set index of the button being pressed (for color of the buttons)

        }
    }
    public void NextQuestion(View view){//this changes the question index (upward), which essentially goes to the next question
        if(questionIndex < questions.length-1){
            questionIndex++;
            setQuestionText();
            setButtonColors();
        }

    }
    public void PrevQuestion(View view){//this does the same but goes to previous index
        if(questionIndex > 0){
            questionIndex--;
            setQuestionText();
            setButtonColors();
        }
    }

    //TODO: these need to be changed into toasts or when ever he called them. basically this doesn't
    public  void InfoButton(View view){
        setContentView(R.layout.info_page);
    }
    public  void BackButton(View view){
        setContentView(R.layout.activity_main);
    }
    //TODO:
    //values that need to be stored when switching activities:
    //questions
    //questionIndex
    //score
}
